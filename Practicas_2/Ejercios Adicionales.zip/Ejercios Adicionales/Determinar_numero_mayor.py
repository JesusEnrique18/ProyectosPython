Numero1 = float(input("Ingrese un numero A:  "))
Numero2 = float(input("Ingrese un numero B: "))
Numero3 = float(input("Ingrese un numero C: "))

NumeroS = Numero1 + Numero2
if NumeroS == Numero3: 
     print ("El numero A: " + str(Numero1) + " Y El numero B: " + str(Numero2)+ " sumados "  + " son iguales al numero C: "+ str(Numero3))
else:
    print ("Los A y B suamdos, no son iguales al numero C")